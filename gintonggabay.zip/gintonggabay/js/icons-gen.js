export async function makeIcon(size){
  const svg=await (await fetch('icons/icon.svg')).text();
  const img=new Image();img.src='data:image/svg+xml;charset=utf-8,'+encodeURIComponent(svg);
  await img.decode();
  const c=document.createElement('canvas');c.width=c.height=size;
  c.getContext('2d').drawImage(img,0,0,size,size);
  return new Promise(r=>c.toBlob(r,'image/png'));
}
export function setFavicon(){
  const l=document.createElement('link');l.rel='icon';l.type='image/svg+xml';l.href='icons/icon.svg';document.head.appendChild(l);
}
